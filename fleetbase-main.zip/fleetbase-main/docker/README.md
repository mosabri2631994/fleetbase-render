### Docker setup

To populate the database in docker put any `.sql` or `.sql.gz` file(s) into `docker/database` folder.
Then run `docker-compose up`.
