## CI/CD config files

This folder contains examples of configuration files for different CI/CD systems other than Github Actions.
