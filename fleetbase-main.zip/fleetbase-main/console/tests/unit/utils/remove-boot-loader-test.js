import removeBootLoader from '@fleetbase/console/utils/remove-boot-loader';
import { module, test } from 'qunit';

module('Unit | Utility | remove-boot-loader', function () {
    // TODO: Replace this with your real tests.
    test('it works', function (assert) {
        let result = removeBootLoader();
        assert.ok(result);
    });
});
