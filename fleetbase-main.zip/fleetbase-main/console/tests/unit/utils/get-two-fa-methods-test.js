import getTwoFaMethods from '@fleetbase/console/utils/get-two-fa-methods';
import { module, test } from 'qunit';

module('Unit | Utility | get-two-fa-methods', function () {
    // TODO: Replace this with your real tests.
    test('it works', function (assert) {
        let result = getTwoFaMethods();
        assert.ok(result);
    });
});
