import runtimeConfig from '@fleetbase/console/utils/runtime-config';
import { module, test } from 'qunit';

module('Unit | Utility | runtime-config', function () {
    // TODO: Replace this with your real tests.
    test('it works', function (assert) {
        let result = runtimeConfig();
        assert.ok(result);
    });
});
