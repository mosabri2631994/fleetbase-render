import getPermissionAction from '@fleetbase/console/utils/get-permission-action';
import { module, test } from 'qunit';

module('Unit | Utility | get-permission-action', function () {
    // TODO: Replace this with your real tests.
    test('it works', function (assert) {
        let result = getPermissionAction();
        assert.ok(result);
    });
});
