import getPermissionResource from '@fleetbase/console/utils/get-permission-resource';
import { module, test } from 'qunit';

module('Unit | Utility | get-permission-resource', function () {
    // TODO: Replace this with your real tests.
    test('it works', function (assert) {
        let result = getPermissionResource();
        assert.ok(result);
    });
});
