import Component from '@glimmer/component';

export default class ModalsLeaveOrganizationComponent extends Component {}
