import Component from '@glimmer/component';

export default class ModalsEditOrganizationComponent extends Component {}
