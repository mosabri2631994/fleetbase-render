import Component from '@glimmer/component';

export default class Configure2faComponent extends Component {}
