import Model from '@ember-data/model';

export default class UserDeviceModel extends Model {}
