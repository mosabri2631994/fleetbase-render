import Model from '@ember-data/model';

export default class SettingModel extends Model {}
