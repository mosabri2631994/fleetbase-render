import Controller from '@ember/controller';

export default class ConsoleAdminConfigCacheController extends Controller {}
