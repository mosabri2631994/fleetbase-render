import Controller from '@ember/controller';

export default class ConsoleAdminConfigServicesController extends Controller {}
