import Controller from '@ember/controller';

export default class ConsoleAdminConfigFilesystemController extends Controller {}
