import Controller from '@ember/controller';

export default class ConsoleSettingsAuthController extends Controller {}
