export { default } from '@fleetbase/ember-core/adapters/application';
