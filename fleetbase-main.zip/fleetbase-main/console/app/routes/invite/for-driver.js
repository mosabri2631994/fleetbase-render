import Route from '@ember/routing/route';

export default class InviteForDriverRoute extends Route {}
