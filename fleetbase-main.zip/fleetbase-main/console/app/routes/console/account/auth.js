import Route from '@ember/routing/route';

export default class ConsoleAccountAuthRoute extends Route {}
