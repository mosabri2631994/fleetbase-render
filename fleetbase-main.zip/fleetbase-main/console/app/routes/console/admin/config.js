import Route from '@ember/routing/route';

export default class ConsoleAdminConfigRoute extends Route {}
