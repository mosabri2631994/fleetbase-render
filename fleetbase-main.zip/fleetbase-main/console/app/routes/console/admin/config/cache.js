import Route from '@ember/routing/route';

export default class ConsoleAdminConfigCacheRoute extends Route {}
