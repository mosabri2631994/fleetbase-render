import Route from '@ember/routing/route';

export default class ConsoleAdminConfigServicesRoute extends Route {}
