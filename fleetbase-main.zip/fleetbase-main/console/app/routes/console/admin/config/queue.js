import Route from '@ember/routing/route';

export default class ConsoleAdminConfigQueueRoute extends Route {}
