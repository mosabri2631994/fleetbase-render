import Route from '@ember/routing/route';

export default class ConsoleAdminTwoFaSettingsRoute extends Route {}
