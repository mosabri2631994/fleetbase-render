import Route from '@ember/routing/route';

export default class ConsoleSettingsTwoFaRoute extends Route {}
