import Route from '@ember/routing/route';

export default class ConsoleSettingsAuthRoute extends Route {}
