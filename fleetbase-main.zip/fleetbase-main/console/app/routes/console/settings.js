import Route from '@ember/routing/route';

export default class ConsoleSettingsRoute extends Route {}
