import ApplicationSerializer from '@fleetbase/ember-core/serializers/application';

export default class NotificationSerializer extends ApplicationSerializer {
    primaryKey = 'id';
}
