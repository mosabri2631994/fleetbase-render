import ApplicationSerializer from '@fleetbase/ember-core/serializers/application';

export default class PermissionSerializer extends ApplicationSerializer {
    primaryKey = 'id';
}
