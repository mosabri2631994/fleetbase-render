import ApplicationSerializer from '@fleetbase/ember-core/serializers/application';

export default class DashboardWidgetSerializer extends ApplicationSerializer {}
