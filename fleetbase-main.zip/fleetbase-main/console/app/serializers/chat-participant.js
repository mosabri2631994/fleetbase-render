import ApplicationSerializer from '@fleetbase/ember-core/serializers/application';

export default class ChatParticipantSerializer extends ApplicationSerializer {}
